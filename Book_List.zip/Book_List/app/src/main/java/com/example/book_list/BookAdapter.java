package com.example.book_list;

public class BookAdapter {
}
